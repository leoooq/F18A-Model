/*
 * F18_HARV_6DOF_cmex.c
 *
 * F/A-18 HARV 六自由度模型 C-MEX S-Function
 *
 * 连续状态 (15):
 *   x[0-2]:   xa, ya, za          惯性系位置 (NED)
 *   x[3-5]:   V, chi, gamma       速度, 航迹偏角, 航迹倾角
 *   x[6-8]:   alpha, mu, beta     迎角, 气流滚转角, 侧滑角
 *   x[9-11]:  p, q, r             体轴角速率
 *   x[12-14]: phi, theta, psi     欧拉角 (精确运动学)
 *
 * 输入 (4):  de, da, dr, T   舵偏和推力
 * 输出 (15): 全部15个状态
 *
 */

#define S_FUNCTION_NAME  F18_HARV_6DOF_cmex
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"
#include <math.h>

/* 常量 */
#define NX   15    /* 连续状态数 */
#define NU   4     /* 输入数 */
#define NY   15    /* 输出数 */

/* 飞行器参数 */
#define MASS    14000.0
#define GRAV    9.81
#define RHO     1.225
#define SREF    37.16
#define BREF    11.4
#define CBAR    3.488

/* 转动惯量 */
#define IXX     31184.0
#define IYY     156910.0
#define IZZ     230411.0
#define IXZ     (-4028.0)

/* 气动系数 */
#define CL0_    0.8229
#define CLA_    2.7584
#define CLDE_   0.4894
#define CD0_    0.1027
#define CDA_    0.7476
#define CYB_    (-0.8022)
#define CLB_    (-0.1203)
#define CLP_    (-0.38)
#define CLR_    0.013
#define CLDA_   0.1834
#define CLDR_   0.0172
#define CM0_    0.0603
#define CMA_    (-0.4260)
#define CMQ_    (-3.5432)
#define CMDE_   (-0.6596)
#define CNB_    0.0974
#define CNP_    (-0.05)
#define CNR_    (-0.24)
#define CNDA_   0.0115
#define CNDR_   (-0.0859)

/* 配平初始值 */
#define ALPHA0  (7.84 * 3.14159265358979 / 180.0)
#define V0      70.0
#define ZA0     (-185.0)

/* 防奇异阈值 */
#define EPS     1.0e-6

/*===========================================================================*/
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, 0);
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) return;

    ssSetNumContStates(S, NX);
    ssSetNumDiscStates(S, 0);

    if (!ssSetNumInputPorts(S, 1)) return;
    ssSetInputPortWidth(S, 0, NU);
    ssSetInputPortDirectFeedThrough(S, 0, 0);  /* 无直接馈通 */
    ssSetInputPortRequiredContiguous(S, 0, 1);

    if (!ssSetNumOutputPorts(S, 1)) return;
    ssSetOutputPortWidth(S, 0, NY);

    ssSetNumSampleTimes(S, 1);
    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE);
}

/*===========================================================================*/
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, CONTINUOUS_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}

/*===========================================================================*/
#define MDL_INITIALIZE_CONDITIONS
static void mdlInitializeConditions(SimStruct *S)
{
    real_T *x = ssGetContStates(S);
    int i;

    for (i = 0; i < NX; i++) x[i] = 0.0;

    x[2]  = ZA0;       /* za = -185 */
    x[3]  = V0;        /* V = 70 */
    x[6]  = ALPHA0;    /* alpha */
    x[13] = ALPHA0;    /* theta = alpha (配平) */
}

/*===========================================================================*/
static void mdlOutputs(SimStruct *S, int_T tid)
{
    real_T *y = ssGetOutputPortRealSignal(S, 0);
    real_T *x = ssGetContStates(S);
    int i;

    for (i = 0; i < NY; i++) {
        y[i] = x[i];
    }
}

/*===========================================================================*/
#define MDL_DERIVATIVES
static void mdlDerivatives(SimStruct *S)
{
    real_T *dx = ssGetdX(S);
    real_T *x  = ssGetContStates(S);
    const real_T *u = ssGetInputPortRealSignal(S, 0);

    /* 输入 */
    real_T de = u[0];
    real_T da = u[1];
    real_T dr = u[2];
    real_T T  = u[3];

    /* 状态 */
    real_T V     = x[3];
    real_T chi   = x[4];
    real_T gam   = x[5];
    real_T alpha = x[6];
    real_T mu    = x[7];
    real_T beta  = x[8];
    real_T p     = x[9];
    real_T q     = x[10];
    real_T r     = x[11];
    real_T phi   = x[12];
    real_T theta = x[13];

    /* 三角函数 */
    real_T ca, sa, cb, sb, cg, sg, cm, sm, cp, sp, ct, st;
    real_T tb;

    /* 惯量耦合 */
    real_T Sigma, I1, I2, I3, I4, I5, I6, I7, I8, I9;

    /* 气动 */
    real_T qbar, L_aero, D_aero, Y_aero;
    real_T pb2V, rb2V, qc2V;
    real_T Lbar, Mbar, Nbar;

    /* 导数 */
    real_T V_dot, chi_dot, gam_dot;
    real_T alpha_dot, mu_dot, beta_dot;
    real_T p_dot, q_dot, r_dot;
    real_T phi_dot, theta_dot, psi_dot;

    /* 防奇异: V */
    if (V < 1.0) V = 1.0;

    /* 三角函数计算 */
    ca = cos(alpha);  sa = sin(alpha);
    cb = cos(beta);   sb = sin(beta);
    cg = cos(gam);    sg = sin(gam);
    cm = cos(mu);     sm = sin(mu);
    cp = cos(phi);    sp = sin(phi);
    ct = cos(theta);  st = sin(theta);

    /* 防奇异 */
    if (fabs(cb) < EPS) cb = (cb >= 0.0) ? EPS : -EPS;
    if (fabs(cg) < EPS) cg = (cg >= 0.0) ? EPS : -EPS;
    if (fabs(ct) < EPS) ct = (ct >= 0.0) ? EPS : -EPS;
    tb = sb / cb;   /* tan(beta) */

    /* ===== 惯量耦合系数 ===== */
    Sigma = IXX * IZZ - IXZ * IXZ;
    I1 = ((IYY - IZZ) * IZZ - IXZ * IXZ) / Sigma;
    I2 = ((IXX - IYY + IZZ) * IXZ) / Sigma;
    I3 = IZZ / Sigma;
    I4 = IXZ / Sigma;
    I5 = (IZZ - IXX) / IYY;
    I6 = IXZ / IYY;
    I7 = 1.0 / IYY;
    I8 = (IXX * (IXX - IYY) + IXZ * IXZ) / Sigma;
    I9 = IXX / Sigma;

    /* ===== 动压和气动力 ===== */
    qbar = 0.5 * RHO * V * V;

    L_aero = qbar * SREF * (CL0_ + CLA_ * alpha + CLDE_ * de);
    D_aero = qbar * SREF * (CD0_ + CDA_ * alpha);
    Y_aero = qbar * SREF * (CYB_ * beta);

    pb2V = p * BREF / (2.0 * V);
    rb2V = r * BREF / (2.0 * V);
    qc2V = q * CBAR / (2.0 * V);

    Lbar = qbar * SREF * BREF * (CLB_ * beta + CLP_ * pb2V + CLR_ * rb2V
                                  + CLDA_ * da + CLDR_ * dr);
    Mbar = qbar * SREF * CBAR * (CM0_ + CMA_ * alpha + CMQ_ * qc2V
                                  + CMDE_ * de);
    Nbar = qbar * SREF * BREF * (CNB_ * beta + CNP_ * pb2V + CNR_ * rb2V
                                  + CNDA_ * da + CNDR_ * dr);

    /* ===== 导航方程 ===== */
    dx[0] =  V * cg * cos(chi);      /* xa_dot */
    dx[1] =  V * cg * sin(chi);      /* ya_dot */
    dx[2] = -V * sg;                 /* za_dot */

    /* ===== 力方程 ===== */
    V_dot = (T * ca * cb - D_aero - MASS * GRAV * sg) / MASS;

    chi_dot = (T * (sa * sm - ca * sb * cm) + Y_aero * cm + L_aero * sm)
              / (MASS * V * cg);

    gam_dot = (T * (ca * sb * sm + sa * cm) - Y_aero * sm + L_aero * cm
              - MASS * GRAV * cg) / (MASS * V);

    dx[3] = V_dot;
    dx[4] = chi_dot;
    dx[5] = gam_dot;

    /* ===== 气动角动力学 ===== */
    alpha_dot = q - (p * ca + r * sa) * tb
              - (L_aero - MASS * GRAV * cg * cm) / (MASS * V * cb)
              - sa / (MASS * V * cb) * T;

    mu_dot = (sg + cg * sm * tb) * chi_dot
           + gam_dot * cm * tb
           + ca / cb * p + sa / cb * r;

    beta_dot = chi_dot * cg * cm - gam_dot * sm + sa * p - ca * r;

    dx[6] = alpha_dot;
    dx[7] = mu_dot;
    dx[8] = beta_dot;

    /* ===== 力矩方程 ===== */
    p_dot =  I1 * q * r + I2 * p * q + I3 * Lbar + I4 * Nbar;
    q_dot =  I5 * p * r + I6 * (r * r - p * p) + I7 * Mbar;
    r_dot = -I2 * q * r + I8 * p * q + I4 * Lbar + I9 * Nbar;

    dx[9]  = p_dot;
    dx[10] = q_dot;
    dx[11] = r_dot;

    /* ===== 欧拉角运动学 =====
     *
     *  [p]   [1,     0,      -sin(theta)        ] [phi_dot  ]
     *  [q] = [0,  cos(phi),   sin(phi)*cos(theta)] [theta_dot]
     *  [r]   [0, -sin(phi),   cos(phi)*cos(theta)] [psi_dot  ]
     *
     *  det = cos(theta), 反解:
     */
    phi_dot   = p + (q * sp + r * cp) * st / ct;
    theta_dot = q * cp - r * sp;
    psi_dot   = (q * sp + r * cp) / ct;

    dx[12] = phi_dot;
    dx[13] = theta_dot;
    dx[14] = psi_dot;
}

/*===========================================================================*/
static void mdlTerminate(SimStruct *S)
{
    /* 无需清理 */
}

/*===========================================================================*/
/* 必须的 Simulink 接口 trailer */
#ifdef MATLAB_MEX_FILE
#include "simulink.c"
#else
#include "cg_sfun.h"
#endif
